#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
path = __file__
sys.path.append(path)

import pandas as pd
import os
import numpy as np
import pickle
import utils.evaluation as ev
import time
import threading as thd

def anomaly_prediction(weigh_data, label_data, C, threshold):
	""" detect anomalies by projecting into a subspace with C

	Args:
	--------
	weigh_data: weighted raw data
	label_data: the labels list
	threshold: used as the threshold, which determines the anomalies
	C: the projection matrix

	Returns:
	--------

	"""
	print ('anomaly detecting with the history logs...')
	event_num, inst_size  = weigh_data.shape
	predict_results = np.zeros((inst_size),int)
	for i in range(inst_size):
		ya = np.dot(C,weigh_data[:,i])
		SPE = np.dot(ya,ya)
		if SPE > threshold:
			predict_results[i] = 1	#1 represent failure
	assert len(label_data) == len(predict_results)
	ev.evaluate(label_data, predict_results)


if __name__ == '__main__':
	
	with open('saved_model_b/model_b.pickle','rb') as file:
		model = pickle.load(file)
		#print(model[0])
		C = model[0]
		threshold = model[1]

	testset = np.loadtxt(open('saved_model_b/testset_b.csv','rb'), delimiter = ',', skiprows = 0)
	print(testset.shape)
	weigh_data_all = testset[:-1, :]
	print(weigh_data_all.shape)
	label_data_all = testset[-1, :]
	print(label_data_all.shape)
	#print(len(label_data_all.tolist()))

	#loop_for_10s
	while True:
		index=np.random.randint(weigh_data_all.shape[1],size=1000)
		weigh_data = weigh_data_all[:,index]
		label_data = label_data_all[index].tolist()
		anomaly_prediction(weigh_data, label_data, C, threshold)
		print("\n")
		time.sleep(10)

	#anomaly_prediction(weigh_data, label_data, C, threshold)


